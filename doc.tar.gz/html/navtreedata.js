/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "My Project", "index.html", [
    [ "gRPC C++ - Building from source", "md__b_u_i_l_d_i_n_g.html", [
      [ "Pre-requisites", "md__b_u_i_l_d_i_n_g.html#autotoc_md0", [
        [ "Linux", "md__b_u_i_l_d_i_n_g.html#autotoc_md1", null ],
        [ "MacOS", "md__b_u_i_l_d_i_n_g.html#autotoc_md2", null ],
        [ "Windows", "md__b_u_i_l_d_i_n_g.html#autotoc_md3", null ]
      ] ],
      [ "Clone the repository (including submodules)", "md__b_u_i_l_d_i_n_g.html#autotoc_md4", [
        [ "Unix", "md__b_u_i_l_d_i_n_g.html#autotoc_md5", null ],
        [ "Windows", "md__b_u_i_l_d_i_n_g.html#autotoc_md6", null ]
      ] ],
      [ "Build from source", "md__b_u_i_l_d_i_n_g.html#autotoc_md7", [
        [ "Building with bazel (recommended)", "md__b_u_i_l_d_i_n_g.html#autotoc_md8", null ],
        [ "Building with CMake", "md__b_u_i_l_d_i_n_g.html#autotoc_md9", [
          [ "Linux/Unix, Using Make", "md__b_u_i_l_d_i_n_g.html#autotoc_md10", null ],
          [ "Windows, Using Visual Studio 2022 or later", "md__b_u_i_l_d_i_n_g.html#autotoc_md11", null ],
          [ "Windows, Using Ninja (faster build).", "md__b_u_i_l_d_i_n_g.html#autotoc_md12", null ],
          [ "Windows: A note on building shared libs (DLLs)", "md__b_u_i_l_d_i_n_g.html#autotoc_md13", null ],
          [ "Consistent standard C++ version", "md__b_u_i_l_d_i_n_g.html#autotoc_md14", null ],
          [ "Dependency management", "md__b_u_i_l_d_i_n_g.html#autotoc_md15", null ],
          [ "Install after build", "md__b_u_i_l_d_i_n_g.html#autotoc_md16", null ],
          [ "Cross-compiling", "md__b_u_i_l_d_i_n_g.html#autotoc_md17", null ],
          [ "A note on SONAME and its ABI compatibility implications in the cmake build", "md__b_u_i_l_d_i_n_g.html#autotoc_md18", null ]
        ] ],
        [ "Building with make on UNIX systems (deprecated)", "md__b_u_i_l_d_i_n_g.html#autotoc_md19", [
          [ "A note on protoc", "md__b_u_i_l_d_i_n_g.html#autotoc_md20", null ]
        ] ]
      ] ]
    ] ],
    [ "Community Code of Conduct", "md__c_o_d_e-_o_f-_c_o_n_d_u_c_t.html", null ],
    [ "gRPC Concepts Overview", "md__c_o_n_c_e_p_t_s.html", [
      [ "Interface", "md__c_o_n_c_e_p_t_s.html#autotoc_md23", [
        [ "Invoking & handling remote calls", "md__c_o_n_c_e_p_t_s.html#autotoc_md24", [
          [ "Synchronous vs. asynchronous", "md__c_o_n_c_e_p_t_s.html#autotoc_md25", null ]
        ] ]
      ] ],
      [ "Streaming", "md__c_o_n_c_e_p_t_s.html#autotoc_md26", null ],
      [ "Protocol", "md__c_o_n_c_e_p_t_s.html#autotoc_md27", [
        [ "Abstract gRPC protocol", "md__c_o_n_c_e_p_t_s.html#autotoc_md28", null ],
        [ "Implementation over HTTP/2", "md__c_o_n_c_e_p_t_s.html#autotoc_md29", null ],
        [ "Flow Control", "md__c_o_n_c_e_p_t_s.html#autotoc_md30", null ]
      ] ]
    ] ],
    [ "How to contribute", "md__c_o_n_t_r_i_b_u_t_i_n_g.html", [
      [ "Legal requirements", "md__c_o_n_t_r_i_b_u_t_i_n_g.html#autotoc_md32", null ],
      [ "Cloning the repository", "md__c_o_n_t_r_i_b_u_t_i_n_g.html#autotoc_md33", null ],
      [ "Building & Running tests", "md__c_o_n_t_r_i_b_u_t_i_n_g.html#autotoc_md34", null ],
      [ "Generated project files", "md__c_o_n_t_r_i_b_u_t_i_n_g.html#autotoc_md35", null ],
      [ "Guidelines for Pull Requests", "md__c_o_n_t_r_i_b_u_t_i_n_g.html#autotoc_md36", null ],
      [ "Obtaining Commit Access", "md__c_o_n_t_r_i_b_u_t_i_n_g.html#autotoc_md37", [
        [ "Obtaining Commit Access without Code Contributions", "md__c_o_n_t_r_i_b_u_t_i_n_g.html#autotoc_md38", null ]
      ] ]
    ] ],
    [ "Contributing to gRPC: A Step-By-Step Guide", "md__c_o_n_t_r_i_b_u_t_i_n_g___s_t_e_p_s.html", [
      [ "Prerequisites", "md__c_o_n_t_r_i_b_u_t_i_n_g___s_t_e_p_s.html#autotoc_md40", null ],
      [ "Steps to Contribute gRPC C++ Code", "md__c_o_n_t_r_i_b_u_t_i_n_g___s_t_e_p_s.html#autotoc_md41", [
        [ "Fork and Clone the Repository", "md__c_o_n_t_r_i_b_u_t_i_n_g___s_t_e_p_s.html#autotoc_md42", null ],
        [ "Prepare and Push Your Commit", "md__c_o_n_t_r_i_b_u_t_i_n_g___s_t_e_p_s.html#autotoc_md43", null ],
        [ "Prepare a Pull Request", "md__c_o_n_t_r_i_b_u_t_i_n_g___s_t_e_p_s.html#autotoc_md44", null ],
        [ "Pull Request Status - Safe Review", "md__c_o_n_t_r_i_b_u_t_i_n_g___s_t_e_p_s.html#autotoc_md45", null ],
        [ "Pull Request Status - Green", "md__c_o_n_t_r_i_b_u_t_i_n_g___s_t_e_p_s.html#autotoc_md46", null ],
        [ "Pull Request Approval", "md__c_o_n_t_r_i_b_u_t_i_n_g___s_t_e_p_s.html#autotoc_md47", null ],
        [ "Submission", "md__c_o_n_t_r_i_b_u_t_i_n_g___s_t_e_p_s.html#autotoc_md48", null ]
      ] ]
    ] ],
    [ "GOVERNANCE", "md__g_o_v_e_r_n_a_n_c_e.html", null ],
    [ "MAINTAINERS", "md__m_a_i_n_t_a_i_n_e_r_s.html", null ],
    [ "Top-level Items by language", "md__m_a_n_i_f_e_s_t.html", [
      [ "Bazel", "md__m_a_n_i_f_e_s_t.html#autotoc_md52", null ],
      [ "Objective-C", "md__m_a_n_i_f_e_s_t.html#autotoc_md53", null ],
      [ "PHP", "md__m_a_n_i_f_e_s_t.html#autotoc_md54", null ],
      [ "Python", "md__m_a_n_i_f_e_s_t.html#autotoc_md55", null ],
      [ "Ruby", "md__m_a_n_i_f_e_s_t.html#autotoc_md56", null ]
    ] ],
    [ "gRPC – An RPC library and framework", "md__r_e_a_d_m_e.html", [
      [ "To start using gRPC", "md__r_e_a_d_m_e.html#autotoc_md58", null ],
      [ "To start developing gRPC", "md__r_e_a_d_m_e.html#autotoc_md59", null ],
      [ "Troubleshooting", "md__r_e_a_d_m_e.html#autotoc_md60", null ],
      [ "Performance", "md__r_e_a_d_m_e.html#autotoc_md61", null ],
      [ "Concepts", "md__r_e_a_d_m_e.html#autotoc_md62", null ],
      [ "About This Repository", "md__r_e_a_d_m_e.html#autotoc_md63", null ]
    ] ],
    [ "Security Policy", "md__s_e_c_u_r_i_t_y.html", null ],
    [ "Troubleshooting gRPC", "md__t_r_o_u_b_l_e_s_h_o_o_t_i_n_g.html", [
      [ "Enabling extra logging and tracing", "md__t_r_o_u_b_l_e_s_h_o_o_t_i_n_g.html#autotoc_md66", null ],
      [ "Setting Logging Severity and Verbosity", "md__t_r_o_u_b_l_e_s_h_o_o_t_i_n_g.html#autotoc_md67", null ],
      [ "GRPC_VERBOSITY", "md__t_r_o_u_b_l_e_s_h_o_o_t_i_n_g.html#autotoc_md68", null ],
      [ "GRPC_TRACE", "md__t_r_o_u_b_l_e_s_h_o_o_t_i_n_g.html#autotoc_md69", null ],
      [ "Preventing gRPC Log Noise", "md__t_r_o_u_b_l_e_s_h_o_o_t_i_n_g.html#autotoc_md70", null ]
    ] ],
    [ "Namespaces", "namespaces.html", [
      [ "Namespace List", "namespaces.html", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Functions", "namespacemembers_func.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"index.html"
];

var SYNCONMSG = 'click to disable panel synchronization';
var SYNCOFFMSG = 'click to enable panel synchronization';