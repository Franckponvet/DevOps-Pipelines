var namespaces_dup =
[
    [ "setup", "namespacesetup.html", [
      [ "_env_bool_value", "namespacesetup.html#ae3e92f8de840e5ab04ddab31f4f6b65a", null ],
      [ "check_linker_need_libatomic", "namespacesetup.html#afbe502152700d670c472295dec019005", null ]
    ] ]
];