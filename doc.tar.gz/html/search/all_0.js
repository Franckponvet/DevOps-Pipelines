var searchData=
[
  ['2_0',['Implementation over HTTP/2',['../md__c_o_n_c_e_p_t_s.html#autotoc_md29',1,'']]],
  ['2022_20or_20later_1',['Windows, Using Visual Studio 2022 or later',['../md__b_u_i_l_d_i_n_g.html#autotoc_md11',1,'']]]
];
