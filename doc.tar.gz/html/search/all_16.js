var searchData=
[
  ['your_20commit_0',['Prepare and Push Your Commit',['../md__c_o_n_t_r_i_b_u_t_i_n_g___s_t_e_p_s.html#autotoc_md43',1,'']]]
];
