var searchData=
[
  ['items_20by_20language_0',['Top-level Items by language',['../md__m_a_n_i_f_e_s_t.html',1,'']]]
];
