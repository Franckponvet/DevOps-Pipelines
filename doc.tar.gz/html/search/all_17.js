var searchData=
[
  ['–_20an_20rpc_20library_20and_20framework_0',['gRPC – An RPC library and framework',['../md__r_e_a_d_m_e.html',1,'']]]
];
