var searchData=
[
  ['recommended_0',['Building with bazel (recommended)',['../md__b_u_i_l_d_i_n_g.html#autotoc_md8',1,'']]],
  ['remote_20calls_1',['Invoking &amp; handling remote calls',['../md__c_o_n_c_e_p_t_s.html#autotoc_md24',1,'']]],
  ['repository_2',['Repository',['../md__r_e_a_d_m_e.html#autotoc_md63',1,'About This Repository'],['../md__c_o_n_t_r_i_b_u_t_i_n_g___s_t_e_p_s.html#autotoc_md42',1,'Fork and Clone the Repository']]],
  ['repository_3',['Cloning the repository',['../md__c_o_n_t_r_i_b_u_t_i_n_g.html#autotoc_md33',1,'']]],
  ['repository_20including_20submodules_4',['Clone the repository (including submodules)',['../md__b_u_i_l_d_i_n_g.html#autotoc_md4',1,'']]],
  ['request_5',['Prepare a Pull Request',['../md__c_o_n_t_r_i_b_u_t_i_n_g___s_t_e_p_s.html#autotoc_md44',1,'']]],
  ['request_20approval_6',['Pull Request Approval',['../md__c_o_n_t_r_i_b_u_t_i_n_g___s_t_e_p_s.html#autotoc_md47',1,'']]],
  ['request_20status_20green_7',['Pull Request Status - Green',['../md__c_o_n_t_r_i_b_u_t_i_n_g___s_t_e_p_s.html#autotoc_md46',1,'']]],
  ['request_20status_20safe_20review_8',['Pull Request Status - Safe Review',['../md__c_o_n_t_r_i_b_u_t_i_n_g___s_t_e_p_s.html#autotoc_md45',1,'']]],
  ['requests_9',['Guidelines for Pull Requests',['../md__c_o_n_t_r_i_b_u_t_i_n_g.html#autotoc_md36',1,'']]],
  ['requirements_10',['Legal requirements',['../md__c_o_n_t_r_i_b_u_t_i_n_g.html#autotoc_md32',1,'']]],
  ['requisites_11',['Pre-requisites',['../md__b_u_i_l_d_i_n_g.html#autotoc_md0',1,'']]],
  ['review_12',['Pull Request Status - Safe Review',['../md__c_o_n_t_r_i_b_u_t_i_n_g___s_t_e_p_s.html#autotoc_md45',1,'']]],
  ['rpc_20library_20and_20framework_13',['gRPC – An RPC library and framework',['../md__r_e_a_d_m_e.html',1,'']]],
  ['ruby_14',['Ruby',['../md__m_a_n_i_f_e_s_t.html#autotoc_md56',1,'']]],
  ['running_20tests_15',['Building &amp; Running tests',['../md__c_o_n_t_r_i_b_u_t_i_n_g.html#autotoc_md34',1,'']]]
];
